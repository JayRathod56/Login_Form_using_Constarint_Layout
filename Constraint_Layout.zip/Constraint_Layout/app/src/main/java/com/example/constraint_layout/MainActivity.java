package com.example.constraint_layout;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView untxt;
    TextView pwdtxt;

    Button reset;
    Button submit;

    int counter = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        untxt = findViewById(R.id.username);
        pwdtxt = findViewById(R.id.password);

        reset = findViewById(R.id.reset);
        submit = findViewById(R.id.submit);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                untxt.setText("");
                pwdtxt.setText("");
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(untxt.getText().toString().equals("Jay56") && pwdtxt.getText().toString().equals("2001")){
                    untxt.setBackgroundColor(Color.WHITE);
                    pwdtxt.setBackgroundColor(Color.WHITE);
                    Toast.makeText(getApplicationContext(), "Login Successfull Redirecting...", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();
                    untxt.setBackgroundColor(Color.RED);
                    pwdtxt.setBackgroundColor(Color.RED);
                    counter--;

                    String atmp = "Remaining "+counter+" attempts";

                    Toast.makeText(getApplicationContext(), atmp, Toast.LENGTH_LONG).show();


                    if (counter==0){
                        Toast.makeText(getApplicationContext(), "Failed in 3 login attempts, Terminating Access!!!", Toast.LENGTH_LONG).show();
                        submit.setEnabled(false);
                    }
                }
            }
        });

    }
}